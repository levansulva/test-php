
<?php
$output = shell_exec('whoami');
echo "<pre>$output</pre>";
?>
